#ifdef HAVE_CONGIG_H
# include <config.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "admin.h"
#include <gtk/gtk.h>
enum
{
   
  
  NOM,
  PRENOM,
  DNAISSANCE,
  EMAIL,
  LOGIN,
  MDP,
  SEXE,
  TELEPHONE,
  COLUMNS,
};

void ajouter_admin(admin a)
{
FILE* f;
f=fopen("admin.txt","a+");
  if(f!=NULL)
   {
   fprintf(f,"%s %s %s %s %s %s %s  %s \n",a.nom,a.prenom,a.dnaissance,a.email,a.login,a.mdp,a.sexe,a.telephone);
   }
fclose(f);
}
