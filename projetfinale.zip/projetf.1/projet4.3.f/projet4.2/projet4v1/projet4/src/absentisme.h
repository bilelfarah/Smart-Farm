#include <gtk/gtk.h>
typedef struct
{
   int jour;
   int mois;
   int annee;
}dates;

typedef struct
{
    char id[20];
    char abs[20];
    dates date_abs;

    
}ouv;


void absentisme(ouv n);
void affich_absent(GtkWidget *liste);
void affich_id(GtkWidget *liste, char id1[]);
void afficher_empabsent(GtkWidget *liste);
