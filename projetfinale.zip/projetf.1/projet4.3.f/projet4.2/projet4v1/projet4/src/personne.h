typedef struct 
{
  char username[30];
  char password[30];
  char nom[30];
  char prenom[30];
  char tel[30];
}personne;

void ajouter_c(personne);

int verifierexistant (char username[]);
