#include <gtk/gtk.h>

typedef struct 
{
char nom[30];
char prenom[30];
char dnaissance[30];
char email[30];
char login[30];
char mdp[30];
char sexe[30];
char telephone[30];
}admin;

void ajouter_admin(admin);
