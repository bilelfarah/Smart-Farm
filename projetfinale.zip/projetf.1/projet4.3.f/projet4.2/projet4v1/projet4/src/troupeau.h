#include <gtk/gtk.h>


typedef struct heure {
int j;
int mo;
int a;
} heure;
typedef struct troupeau {
char ID[10] ;
heure date;
char type [10];
char nourriture [10];
char etat[10];
char sexe [10]; 
} troupeau ;

void ajouter (troupeau tr,heure date );  
void modifier (troupeau tr);
void consulter (GtkWidget *liste);
void suprimer (troupeau tr); 
void recherche (troupeau tr); 



