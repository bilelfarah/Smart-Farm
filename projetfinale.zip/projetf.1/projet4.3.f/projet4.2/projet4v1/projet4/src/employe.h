#include <gtk/gtk.h>

typedef struct 
{
char id[30];
char nom[30];
char prenom[30];
char dnaissance[30];
char email[30];
char login[30];
char mdp[30];
char sexe[30];
char profession[30];
}employe;

void afficher_employe(GtkWidget *liste);
void ajouter_employe(employe );
void Supprimer_employe (employe);
void Modifier_employe(employe );
